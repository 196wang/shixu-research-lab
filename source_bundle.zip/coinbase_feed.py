"""Manual Coinbase Exchange BTC/USD and ETH/USD cache for Beijing-day scoring.

The TradingView iframe remains display-only. This module fetches the same
exchange's public hourly candles and aggregates only complete UTC+8 days.
Raw HTTP responses and provenance are retained separately from legacy USDT.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from urllib import error, parse, request
import hashlib
import json
import re
import sqlite3
import threading
import time as clock_time
import uuid

LOCAL = timezone(timedelta(hours=8))
UTC = timezone.utc
HOUR = timedelta(hours=1)
DAY = timedelta(days=1)
HOUR_MS = 3_600_000
DAY_MS = 86_400_000
BASE = 'https://api.exchange.coinbase.com'
SYMBOLS = {'BTCUSD': 'BTC-USD', 'ETHUSD': 'ETH-USD'}
MAX_BODY_BYTES = 2_000_000
MAX_DAYS = 180
PAGE_HOURS = 240  # below the documented 300-candle limit


class CoinbaseFeedError(RuntimeError):
    def __init__(self, message, status_code=503):
        super().__init__(message)
        self.status_code = status_code


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def ms(at):
    return int(at.timestamp() * 1000)


def local_open(day):
    return datetime.combine(day, time(), LOCAL)


def price(value, positive=True):
    if isinstance(value, bool) or not isinstance(value, (int, float, str)):
        raise ValueError('invalid_number')
    try:
        result = Decimal(str(value))
    except InvalidOperation as exc:
        raise ValueError('invalid_number') from exc
    if not result.is_finite() or (result <= 0 if positive else result < 0):
        raise ValueError('invalid_number')
    return result


def token(value):
    # Canonicalize equivalent JSON numbers before comparing repeated fetches.
    return format(value.normalize(), 'f')


def default_transport(product, start, end):
    if product not in SYMBOLS.values() or start.tzinfo is None or end.tzinfo is None:
        raise CoinbaseFeedError('Coinbase 请求参数无效', 400)
    query = parse.urlencode({'start': start.astimezone(UTC).isoformat().replace('+00:00', 'Z'),
                             'end': end.astimezone(UTC).isoformat().replace('+00:00', 'Z'),
                             'granularity': 3600})
    url = BASE + '/products/' + product + '/candles?' + query

    class NoRedirect(request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            return None

    req = request.Request(url, headers={'Accept': 'application/json', 'User-Agent': 'LocalResearchDesk/0.20'}, method='GET')
    opener = request.build_opener(NoRedirect)
    try:
        with opener.open(req, timeout=12) as response:
            body = response.read(MAX_BODY_BYTES + 1)
            status = response.status
    except error.HTTPError as exc:
        body, status = exc.read(MAX_BODY_BYTES + 1), exc.code
    except (OSError, error.URLError) as exc:
        reason = exc.reason if isinstance(exc, error.URLError) else exc
        if isinstance(reason, TimeoutError):
            category = '连接超时'
        elif isinstance(reason, ConnectionRefusedError):
            category = '网络代理无法连接' if request.getproxies().get('https') else '连接被拒绝'
        elif isinstance(reason, OSError):
            category = '网络连接失败'
        else:
            category = '网络请求失败'
        raise CoinbaseFeedError('Coinbase ' + category + '；未写入不完整行情') from exc
    if len(body) > MAX_BODY_BYTES:
        raise CoinbaseFeedError('Coinbase 响应超过大小限制')
    return status, body


def parse_page(body, start, end):
    try:
        rows = json.loads(body)
    except (ValueError, UnicodeDecodeError) as exc:
        raise CoinbaseFeedError('Coinbase 响应不是有效 JSON') from exc
    if not isinstance(rows, list) or len(rows) > 300:
        raise CoinbaseFeedError('Coinbase 蜡烛数量或结构异常')
    parsed = {}
    for row in rows:
        if not isinstance(row, list) or len(row) != 6 or type(row[0]) is not int:
            raise CoinbaseFeedError('Coinbase 小时线结构异常')
        stamp = row[0]
        if stamp % 3600 or not ms(start) <= stamp * 1000 < ms(end):
            # The API documents that some returned buckets may precede start.
            if stamp % 3600:
                raise CoinbaseFeedError('Coinbase 小时线时间戳异常')
            continue
        low, high, opened, closed, volume = (price(row[i], positive=i != 5) for i in range(1, 6))
        if not low <= min(opened, closed) <= max(opened, closed) <= high:
            raise CoinbaseFeedError('Coinbase 小时线价格顺序异常')
        normalized = {'low': token(low), 'high': token(high), 'open': token(opened),
                      'close': token(closed), 'volume': token(volume)}
        if stamp in parsed and parsed[stamp] != normalized:
            raise CoinbaseFeedError('单次 Coinbase 响应内存在冲突小时线')
        parsed[stamp] = normalized
    return parsed


def aggregate(day, hours):
    first = int(local_open(day).timestamp())
    stamps = [first + i * 3600 for i in range(24)]
    if any(stamp not in hours for stamp in stamps):
        return None, ['missing_hour']
    rows = [hours[stamp][0] for stamp in stamps]
    refs = sorted({hours[stamp][1] for stamp in stamps})
    result = {'open_ms': ms(local_open(day)), 'close_ms': ms(local_open(day) + DAY) - 1,
              'open': rows[0]['open'], 'high': token(max(Decimal(r['high']) for r in rows)),
              'low': token(min(Decimal(r['low']) for r in rows)), 'close': rows[-1]['close'],
              'volume': token(sum((Decimal(r['volume']) for r in rows), Decimal(0))),
              'request_id': 'coinbase-pages:' + hashlib.sha256(encode(refs).encode()).hexdigest()[:24],
              'body_sha256': hashlib.sha256(encode([(stamp, hours[stamp][0]) for stamp in stamps]).encode()).hexdigest(),
              'source_request_ids': encode(refs), 'is_closed': 1, 'conflicted': 0}
    return result, []


class CoinbaseMarketFeed:
    def __init__(self, data_dir, transport=None, clock=None):
        self.path = Path(data_dir) / 'coinbase_market.sqlite3'
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.transport = transport or default_transport
        self.clock = clock or (lambda: datetime.now(UTC))
        self.lock = threading.Lock()
        with self.connect() as db:
            db.executescript('''
              CREATE TABLE IF NOT EXISTS requests(id TEXT PRIMARY KEY,symbol TEXT NOT NULL,
                start_utc TEXT NOT NULL,end_utc TEXT NOT NULL,fetched_utc TEXT NOT NULL,
                http_status INTEGER NOT NULL,body BLOB NOT NULL,body_sha256 TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS candles(symbol TEXT NOT NULL,open_ms INTEGER NOT NULL,
                close_ms INTEGER NOT NULL,open TEXT NOT NULL,high TEXT NOT NULL,low TEXT NOT NULL,
                close TEXT NOT NULL,volume TEXT NOT NULL,is_closed INTEGER NOT NULL,
                conflicted INTEGER NOT NULL,request_id TEXT NOT NULL,body_sha256 TEXT NOT NULL,
                source_request_ids TEXT NOT NULL,updated TEXT NOT NULL,PRIMARY KEY(symbol,open_ms));
              CREATE TABLE IF NOT EXISTS gaps(symbol TEXT NOT NULL,open_ms INTEGER NOT NULL,
                reasons TEXT NOT NULL,updated TEXT NOT NULL,PRIMARY KEY(symbol,open_ms));
              CREATE TABLE IF NOT EXISTS state(symbol TEXT PRIMARY KEY,status TEXT NOT NULL,
                range_start TEXT,range_end TEXT,last_attempt TEXT,last_success TEXT,last_error TEXT,
                generation INTEGER NOT NULL DEFAULT 0);
            ''')
            for symbol in SYMBOLS:
                db.execute("INSERT OR IGNORE INTO state(symbol,status) VALUES (?,'empty')", (symbol,))

    @contextmanager
    def connect(self):
        db = sqlite3.connect(str(self.path), timeout=15)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    def refresh(self, symbol='BTCUSD', days=90):
        if symbol not in SYMBOLS or type(days) is not int or not 1 <= days <= MAX_DAYS:
            raise CoinbaseFeedError('仅支持 BTCUSD/ETHUSD，范围为 1–180 个完整北京时间日', 400)
        last = self.clock().astimezone(LOCAL).date() - DAY
        first = last - (days - 1) * DAY
        return self.refresh_range(symbol, first, last)

    def refresh_range(self, symbol, first, last):
        """Fetch an explicit completed-day span; used by bounded historical backfill."""
        if (symbol not in SYMBOLS or type(first) is not date or type(last) is not date
                or first > last or not 1 <= (last - first).days + 1 <= MAX_DAYS
                or last >= self.clock().astimezone(LOCAL).date()):
            raise CoinbaseFeedError('历史回补仅支持 1–180 个已经收盘的北京时间日', 400)
        days = (last - first).days + 1
        if not self.lock.acquire(blocking=False):
            raise CoinbaseFeedError('已有 Coinbase 更新正在进行', 409)
        try:
            with self.connect() as db:
                db.execute('UPDATE state SET last_attempt=? WHERE symbol=?',
                           (self.clock().astimezone(UTC).isoformat(), symbol))
            start, end = local_open(first).astimezone(UTC), local_open(last + DAY).astimezone(UTC)
            pages, hours = [], {}
            cursor = start
            while cursor < end:
                stop = min(end, cursor + PAGE_HOURS * HOUR)
                for attempt in range(2):
                    try:
                        status, body = self.transport(SYMBOLS[symbol], cursor, stop)
                    except CoinbaseFeedError as exc:
                        if attempt or exc.status_code < 500:
                            raise
                        clock_time.sleep(1)
                        continue
                    if status in (429, 500, 502, 503, 504) and not attempt:
                        clock_time.sleep(1)
                        continue
                    break
                if status != 200:
                    raise CoinbaseFeedError(f'Coinbase 返回 HTTP {status}')
                identity = str(uuid.uuid4())
                fetched = self.clock().astimezone(UTC).isoformat()
                parsed = parse_page(body, cursor, stop)
                pages.append((identity, symbol, cursor.isoformat(), stop.isoformat(), fetched,
                              status, body, hashlib.sha256(body).hexdigest()))
                for stamp, row in parsed.items():
                    if stamp in hours and hours[stamp][0] != row:
                        raise CoinbaseFeedError('不同 Coinbase 响应中的小时线冲突，未写入')
                    hours[stamp] = (row, identity)
                cursor = stop
            finished = self.clock().astimezone(UTC).isoformat()
            bars, gaps = {}, {}
            for i in range(days):
                day = first + i * DAY
                bar, reasons = aggregate(day, hours)
                opened = ms(local_open(day))
                if bar:
                    bars[opened] = bar
                else:
                    gaps[opened] = reasons
            conflicts = 0
            with self.connect() as db:
                for page in pages:
                    db.execute('INSERT INTO requests VALUES (?,?,?,?,?,?,?,?)', page)
                for opened, bar in bars.items():
                    existing = db.execute('SELECT * FROM candles WHERE symbol=? AND open_ms=?', (symbol, opened)).fetchone()
                    if existing and any(existing[key] != bar[key] for key in ('open', 'high', 'low', 'close', 'volume')):
                        conflicts += 1
                        db.execute('UPDATE candles SET conflicted=1 WHERE symbol=? AND open_ms=?', (symbol, opened))
                        gaps[opened] = ['source_conflict']
                        continue
                    if not existing:
                        db.execute('INSERT INTO candles VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                                   (symbol, *[bar[key] for key in ('open_ms','close_ms','open','high','low','close','volume','is_closed','conflicted','request_id','body_sha256','source_request_ids')], finished))
                for opened in (ms(local_open(first + i * DAY)) for i in range(days)):
                    if opened in gaps:
                        db.execute('INSERT OR REPLACE INTO gaps VALUES (?,?,?,?)',
                                   (symbol, opened, encode(gaps[opened]), finished))
                    else:
                        db.execute('DELETE FROM gaps WHERE symbol=? AND open_ms=?', (symbol, opened))
                db.execute('''UPDATE state SET status='ready',
                             range_start=CASE WHEN range_start IS NULL OR range_start>? THEN ? ELSE range_start END,
                             range_end=CASE WHEN range_end IS NULL OR range_end<? THEN ? ELSE range_end END,
                             last_attempt=?,last_success=?,last_error=NULL,generation=generation+1
                             WHERE symbol=?''', (first.isoformat(), first.isoformat(), last.isoformat(),
                                               last.isoformat(), finished, finished, symbol))
            return {'symbol': symbol, 'provider': 'Coinbase Exchange', 'days': days,
                    'range': {'start': first.isoformat(), 'end': last.isoformat()},
                    'complete': len(bars) - conflicts, 'missing': len(gaps), 'conflicts': conflicts,
                    'requestCount': len(pages), 'lastSuccessAtUtc': finished}
        except Exception as exc:
            message = str(exc) if isinstance(exc, CoinbaseFeedError) else '内部更新失败：' + type(exc).__name__
            with self.connect() as db:
                db.execute('UPDATE state SET last_error=? WHERE symbol=?', (message, symbol))
            raise
        finally:
            self.lock.release()

    def repair_range(self, symbol, first, last):
        """Fetch only absent completed days; keep valid cached candles and their provenance."""
        if (symbol not in SYMBOLS or type(first) is not date or type(last) is not date
                or first > last or not 1 <= (last - first).days + 1 <= MAX_DAYS
                or last >= self.clock().astimezone(LOCAL).date()):
            raise CoinbaseFeedError('缺口补齐仅支持 1–180 个已经收盘的北京时间日', 400)
        _, candles, gaps = self._snapshot(symbol)
        missing = []
        for i in range((last - first).days + 1):
            day = first + i * DAY
            opened = ms(local_open(day))
            bar = candles.get(opened)
            if not (bar and bar['is_closed'] and not bar['conflicted']) and 'source_conflict' not in gaps.get(opened, []):
                missing.append(day)
        groups = []
        for day in missing:
            if groups and day == groups[-1][-1] + DAY:
                groups[-1].append(day)
            else:
                groups.append([day])
        requests = 0
        for group in groups:
            result = self.refresh_range(symbol, group[0], group[-1])
            requests += result['requestCount']
        state, candles, _ = self._snapshot(symbol)
        complete = sum(bool((bar := candles.get(ms(local_open(first + i * DAY)))) and
                            bar['is_closed'] and not bar['conflicted'])
                       for i in range((last - first).days + 1))
        count = (last - first).days + 1
        return {'symbol': symbol, 'provider': 'Coinbase Exchange',
                'range': {'start': first.isoformat(), 'end': last.isoformat()},
                'days': count, 'requestedDays': len(missing), 'complete': complete,
                'missing': count - complete, 'requestCount': requests,
                'lastSuccessAtUtc': state['last_success']}

    def _snapshot(self, symbol):
        if symbol not in SYMBOLS:
            raise CoinbaseFeedError('Coinbase 交易对无效', 400)
        with self.connect() as db:
            db.execute('BEGIN')
            state = dict(db.execute('SELECT * FROM state WHERE symbol=?', (symbol,)).fetchone())
            state.update({'provider': 'Coinbase Exchange', 'product': SYMBOLS[symbol],
                          'marketType': 'spot', 'dayTimezone': 'UTC+8'})
            candles = {row['open_ms']: dict(row) for row in db.execute(
                'SELECT * FROM candles WHERE symbol=? ORDER BY open_ms', (symbol,))}
            gaps = {row['open_ms']: json.loads(row['reasons']) for row in db.execute(
                'SELECT * FROM gaps WHERE symbol=?', (symbol,))}
        return state, candles, gaps

    def intraday_paths(self, symbol, days):
        """Read verified cached hourly requests for the order of daily extremes."""
        if symbol not in SYMBOLS or len(days) > MAX_DAYS or any(type(day) is not date for day in days):
            raise CoinbaseFeedError('日内诊断日期无效', 400)
        _, candles, _ = self._snapshot(symbol)
        output = {}
        with self.connect() as db:
            for day in days:
                candle = candles.get(ms(local_open(day)))
                if not candle or not candle['is_closed'] or candle['conflicted']:
                    output[day.isoformat()] = {'status': 'unavailable', 'reason': '缺少完整日线'}
                    continue
                try:
                    refs = json.loads(candle['source_request_ids'])
                    if not isinstance(refs, list) or not refs or len(refs) > 24 or any(type(ref) is not str for ref in refs):
                        raise ValueError('invalid provenance')
                    hours = {}
                    for ref in refs:
                        page = db.execute('SELECT * FROM requests WHERE id=? AND symbol=?', (ref, symbol)).fetchone()
                        if not page or hashlib.sha256(page['body']).hexdigest() != page['body_sha256']:
                            raise ValueError('missing or changed request')
                        parsed = parse_page(page['body'], datetime.fromisoformat(page['start_utc']),
                                            datetime.fromisoformat(page['end_utc']))
                        for stamp, row in parsed.items():
                            if stamp in hours and hours[stamp][0] != row:
                                raise ValueError('conflicting hourly candle')
                            hours[stamp] = (row, ref)
                    reconstructed, reasons = aggregate(day, hours)
                    if reasons or not reconstructed or reconstructed['body_sha256'] != candle['body_sha256']:
                        raise ValueError('daily hash mismatch')
                    first = int(local_open(day).timestamp())
                    stamps = [first + i * 3600 for i in range(24)]
                    high_stamp = min(stamps, key=lambda stamp: (-Decimal(hours[stamp][0]['high']), stamp))
                    low_stamp = min(stamps, key=lambda stamp: (Decimal(hours[stamp][0]['low']), stamp))
                    order = 'high_before_low' if high_stamp < low_stamp else 'low_before_high' if low_stamp < high_stamp else 'same_hour'
                    opened = Decimal(candle['open'])
                    output[day.isoformat()] = {'status': 'verified_hourly', 'extremeOrder': order,
                        'highHourLocal': datetime.fromtimestamp(high_stamp, UTC).astimezone(LOCAL).strftime('%H:00'),
                        'lowHourLocal': datetime.fromtimestamp(low_stamp, UTC).astimezone(LOCAL).strftime('%H:00'),
                        'upsidePct': float((Decimal(candle['high']) / opened - 1) * 100),
                        'downsidePct': float((Decimal(candle['low']) / opened - 1) * 100),
                        'rangePct': float((Decimal(candle['high']) - Decimal(candle['low'])) / opened * 100),
                        'candleSha256': candle['body_sha256']}
                except (ValueError, KeyError, CoinbaseFeedError, TypeError):
                    output[day.isoformat()] = {'status': 'unavailable', 'reason': '小时线来源无法复原验证'}
        return output

    def status(self):
        symbols = []
        for symbol in SYMBOLS:
            state, candles, gaps = self._snapshot(symbol)
            symbols.append({'symbol': symbol, 'status': state['status'],
                            'range': {'start': state['range_start'], 'end': state['range_end']},
                            'completeDays': sum(r['is_closed'] and not r['conflicted'] for r in candles.values()),
                            'gapDays': len(gaps), 'lastSuccessAtUtc': state['last_success'],
                            'generation': state['generation'],
                            'lastAttemptAtUtc': state['last_attempt'],
                            'lastError': state['last_error']})
        return {'provider': 'Coinbase Exchange', 'marketType': 'spot', 'timezone': 'UTC+8',
                'manualOnly': True, 'symbols': symbols}

    def history(self, symbol, limit=31):
        if type(limit) is not int or not 1 <= limit <= 180:
            raise CoinbaseFeedError('历史预览范围须为 1–180 日', 400)
        state, candles, gaps = self._snapshot(symbol)
        if not state['range_end']:
            return {'symbol': symbol, 'available': False, 'rows': [], 'provider': 'Coinbase Exchange'}
        end = date.fromisoformat(state['range_end'])
        first = max(date.fromisoformat(state['range_start']), end - (limit - 1) * DAY)
        rows = []
        cursor = first
        while cursor <= end:
            opened = ms(local_open(cursor))
            bar = candles.get(opened)
            rows.append({'date': cursor.isoformat(),
                         'open': bar['open'] if bar and bar['is_closed'] and not bar['conflicted'] else None,
                         'high': bar['high'] if bar and bar['is_closed'] and not bar['conflicted'] else None,
                         'low': bar['low'] if bar and bar['is_closed'] and not bar['conflicted'] else None,
                         'close': bar['close'] if bar and bar['is_closed'] and not bar['conflicted'] else None,
                         'volume': bar['volume'] if bar and bar['is_closed'] and not bar['conflicted'] else None,
                         'gaps': gaps.get(opened, []),
                         'sourceSha256': bar['body_sha256'] if bar else None})
            cursor += DAY
        return {'symbol': symbol, 'available': True, 'provider': 'Coinbase Exchange',
                'timezone': 'UTC+8', 'range': {'start': first.isoformat(), 'end': end.isoformat()},
                'rows': rows, 'lastSuccessAtUtc': state['last_success']}

    def window(self, symbol, center):
        """Read seven calendar slots around an event without fetching or filling prices."""
        if symbol not in SYMBOLS or type(center) is not str or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', center):
            raise CoinbaseFeedError('需要有效资产与 YYYY-MM-DD 北京日期', 400)
        try:
            day = date.fromisoformat(center)
        except ValueError as exc:
            raise CoinbaseFeedError('日期无效', 400) from exc
        if not date(1992, 1, 4) <= day <= date(2099, 12, 28):
            raise CoinbaseFeedError('日期超出七日价格窗口支持范围', 400)
        state, candles, gaps = self._snapshot(symbol)
        today = datetime.now(LOCAL).date()
        rows = []
        for offset in range(-3, 4):
            current = day + offset * DAY
            opened = ms(local_open(current))
            bar = candles.get(opened)
            complete = bool(bar and bar['is_closed'] and not bar['conflicted'] and current < today)
            rows.append({'date': current.isoformat(), 'status': 'future' if current >= today else 'complete' if complete else 'missing',
                         'open': bar['open'] if complete else None, 'high': bar['high'] if complete else None,
                         'low': bar['low'] if complete else None, 'close': bar['close'] if complete else None,
                         'gaps': gaps.get(opened, []) if current < today and not complete else [],
                         'sourceSha256': bar['body_sha256'] if complete else None})
        return {'symbol': symbol, 'provider': 'Coinbase Exchange', 'timezone': 'UTC+8',
                'centerDate': center, 'range': {'start': rows[0]['date'], 'end': rows[-1]['date']},
                'lastSuccessAtUtc': state['last_success'], 'rows': rows}


class ScoringMarketRouter:
    """Keep old USDT records on their historical cache; use Coinbase for USD."""
    def __init__(self, legacy, coinbase):
        self.legacy, self.coinbase = legacy, coinbase

    def _snapshot(self, symbol):
        return self.coinbase._snapshot(symbol) if symbol in SYMBOLS else self.legacy._snapshot(symbol)
